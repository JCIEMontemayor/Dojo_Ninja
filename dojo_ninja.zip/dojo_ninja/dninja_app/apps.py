from django.apps import AppConfig


class DninjaAppConfig(AppConfig):
    name = 'dninja_app'
